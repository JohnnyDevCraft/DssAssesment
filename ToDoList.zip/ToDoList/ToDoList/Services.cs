﻿namespace ToDoList
{
	public static class Services
	{
		public static IAsyncService Async { get; set; }
	}
}